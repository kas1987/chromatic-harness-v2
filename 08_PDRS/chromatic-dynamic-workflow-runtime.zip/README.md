# Chromatic Dynamic Workflow Runtime Bundle

This bundle adds a governed dynamic workflow runtime to Chromatic Harness.

## Included

- PDR for dynamic workflow runtime
- Runtime loop documentation
- Dynamic workflow spec
- Task graph JSON schema
- Permission gate
- Verifier gate
- GO modes
- Workflow run log placeholder

## Recommended Install Path

Copy the contents into the root of your harness repo.

```text
docs/pdr/PDR-DYNAMIC-WORKFLOW-RUNTIME-001.md
docs/workflows/*
```

## Default v2 Pattern

```text
Sonnet plans -> Kimi builds -> Sonnet verifies -> Scribe logs -> Orchestrator queues next
```
