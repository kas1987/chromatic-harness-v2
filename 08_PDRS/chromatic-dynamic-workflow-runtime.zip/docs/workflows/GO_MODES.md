# GO Modes

## Purpose

Define what short commands mean so the harness can continue without vague autonomy.

| Command | Meaning | Mutation |
|---|---|---|
| GO | Pick next safest unblocked task | Allowed if confidence gate passes |
| GO DEEP | Inspect, plan, decompose | No mutation by default |
| GO BUILD | Implement one scoped task | Allowed inside assigned files |
| GO AUDIT | Review and diagnose | No mutation |
| GO VERIFY | Validate previous output | Logs only |
| GO SWARM | Parallel dispatch | Requires approved task graph |

## Default GO Behavior

When user says `GO`:

1. Read project state.
2. Read queue.
3. Select highest priority unblocked task.
4. Build mission packet.
5. Score confidence.
6. Execute only if permitted.
7. Verify and log.
8. Queue next task.
