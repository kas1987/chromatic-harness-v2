# Permission Gate

## Purpose

Prevent dynamic workflows from turning into unbounded or unsafe autonomy.

## Rules

| Action | Permission |
|---|---|
| Read assigned files | Allowed |
| Read unrelated files | Requires justification |
| Edit assigned files | Allowed if confidence >= 75 |
| Edit unassigned files | Halt |
| Delete files | Human approval required |
| Rename major folders | Human approval required |
| Change build/config/deployment | Human approval required |
| Touch secrets/env/auth | Halt |
| Run tests | Allowed |
| Install packages | Human approval required |
| Push/merge/deploy | Human approval required |

## Hard Stops

The agent must stop if:

- the task requires credentials
- destructive action is needed
- production systems are affected
- files outside allowed scope must be changed
- confidence is below required threshold
