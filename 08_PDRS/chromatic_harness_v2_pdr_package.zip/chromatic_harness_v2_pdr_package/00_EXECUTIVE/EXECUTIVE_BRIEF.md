# Executive Brief: Chromatic Harness v2 Layer Completion

## Top-line Decision

Chromatic Harness v2 should pause broad expansion and focus on proving the operational spine:

```text
Mission -> Magnets -> Confidence -> Bead -> Console
```

The repo already has the right conceptual layers. The next sprint must convert those layers into a validated, observable, clickable loop.

## Current Read

| Area | Read |
|---|---|
| Architecture | Strong scaffold; clear separation of governance, runtime, observability, queue, frontend, sandbox |
| Implementation | Started but thin; API and orchestrator exist, but runtime loop is not fully proven |
| Main risk | More scaffolding before E2E proof |
| Best next move | Add smoke tests, schema validation, and minimal frontend panels |
| External repos | Add LangGraph first, then OpenTelemetry, then OpenHands; keep n8n as optional adapter |

## Recommended Build Order

1. E2E smoke test for mission, event, bead, and list endpoints.
2. Schema/package validator.
3. Minimal frontend console with missions, events, confidence/risk, and beads.
4. LangGraph adapter for mission state machine execution.
5. OpenTelemetry adapter for Magnet observability.
6. OpenHands sandbox trial against copied fixture repos only.

## Do Not Do Yet

- Do not add a large agent swarm before tests exist.
- Do not make n8n the harness brain.
- Do not wire external agents directly to live repos.
- Do not keep adding playbooks without validation hooks.
