# Chromatic Harness v2 Layer Completion PDR Package

This package turns the Harness v2 layer review into an execution-ready PDR suite.

## Contents

- `00_EXECUTIVE/EXECUTIVE_BRIEF.md` — decision-ready summary
- `01_PDRS/PDR_CHROMATIC_HARNESS_V2_LAYER_COMPLETION.md` — core PDR
- `02_LAYER_MATRIX/LAYER_GAP_MATRIX.md` — layer-by-layer needs
- `03_GITHUB_ADDS/GITHUB_BORROW_SHORTLIST.md` — external GitHub projects to add/evaluate
- `04_TASK_QUEUE/HARNESS_V2_PRIORITY_QUEUE.md` — prioritized queue
- `05_AGENT_HANDOFFS/` — swarm-ready packets
- `06_GOVERNANCE/GOVERNANCE_GATES.md` — gates and stop rules
- `07_IMPLEMENTATION/IMPLEMENTATION_ROADMAP.md` — phased roadmap
- `08_VALIDATION/VALIDATION_MATRIX.md` — acceptance and test plan

## Recommended first command

Start with the spine:

```text
Mission -> Magnets -> Confidence -> Bead -> Console
```

Do not expand the system further until this loop is proven by smoke tests.
