# Harness v2 Layer Gap Matrix

| Layer | Current Role | Still Needs | Owner Agent | Priority |
|---|---|---|---|---|
| 00 Source of Truth | Manifest, decision log, glossary | `SYSTEM_STATE.md`, `ROADMAP.md`, `VALIDATION_MATRIX.md`, authority hierarchy | archivist | P0 |
| 01 Protocols | CMP, Magnets, MCP, Beads schemas/specs | Schema validator, examples, contract tests | auditor | P0 |
| 02 Runtime | API, orchestrator, magnets | Full execution loop, confidence gate invocation, runtime event persistence | sentinel | P0 |
| 03 Agents | Agent registry and lead docs | Capability matrix, role boundaries, promotion/demotion rules | auditor | P1 |
| 04 Playbooks | GO mode, routing, sandbox, magnets | `PLAYBOOK_INDEX.md`, cross-link checker, stale playbook review | archivist | P1 |
| 05 Frontend Console | Planned dashboard | Mission, events, confidence/risk, beads panels | cartographer | P0 |
| 09 Deployment | Dockerfile and compose | Healthcheck, smoke test command, `.env.example` validator | sentinel | P1 |
| 10 Runtime Logs | AgentOps/log trail | Append-only JSONL schema, rotation rule, privacy class tags | archivist | P1 |
| 11 Sandbox Lab | Safe external agent test area | Fixture repos, eval runner, OpenHands trial protocol | chainbreaker | P1 |
| 12 Handoffs | Templates | Mission packet generator, reviewer packet generator | quartermaster | P2 |

## Highest-Leverage Missing Objects

1. `SYSTEM_STATE.md`
2. `VALIDATION_MATRIX.md`
3. `scripts/smoke_harness_api.py`
4. `scripts/validate_harness_package.py`
5. `05_FRONTEND_CONSOLE` MVP dashboard
6. `02_RUNTIME/adapters/langgraph_adapter.py`
7. `02_RUNTIME/telemetry/otel_adapter.py`
8. `11_SANDBOX_LAB/fixture_repos/README.md`
