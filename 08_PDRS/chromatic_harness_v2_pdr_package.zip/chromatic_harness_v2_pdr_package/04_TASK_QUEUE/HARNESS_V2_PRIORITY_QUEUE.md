# Harness v2 Priority Queue

## P0 — Prove the Spine

### HV2-P0-001 — Add API Smoke Test

- Agent: sentinel
- Mission: Create a script that proves mission, event, and bead endpoints work end-to-end.
- Acceptance Criteria:
  - Creates mission
  - Creates magnet event for mission
  - Creates bead
  - Lists missions and beads
  - Exits nonzero on failure
- Stop Condition: API contract mismatch or missing endpoint.

### HV2-P0-002 — Add Package/Schema Validator

- Agent: auditor
- Mission: Validate required files, schema loadability, and package index consistency.
- Acceptance Criteria:
  - Required paths checked
  - JSON schemas parse
  - YAML files parse
  - Missing files are reported clearly
- Stop Condition: Source-of-truth contradiction.

### HV2-P0-003 — Build Minimal Console Panels

- Agent: cartographer
- Mission: Add first frontend panels for mission dashboard, magnet events, confidence/risk, and beads queue.
- Acceptance Criteria:
  - Connects to API URL
  - Renders mission list
  - Renders bead list
  - Shows event stream per mission
- Stop Condition: Missing API contract.

## P1 — Make Runtime Real

### HV2-P1-004 — Implement Runtime Execution Loop

- Agent: sentinel
- Mission: Expand orchestrator from packet creation to controlled loop execution.
- Acceptance Criteria:
  - Mission enters runtime state
  - Magnets attach and emit events
  - Confidence decision generated
  - Bead generated from outcome
- Stop Condition: Confidence rules unclear.

### HV2-P1-005 — Add LangGraph Adapter

- Agent: chainbreaker
- Mission: Add a replaceable adapter that maps CMP mission packets to LangGraph state flow.
- Acceptance Criteria:
  - Adapter isolated under runtime adapters
  - No global architecture lock-in
  - Sample mission runs through graph fixture
- Stop Condition: Dependency friction exceeds scope.

### HV2-P1-006 — Add OpenTelemetry Adapter

- Agent: auditor
- Mission: Map Magnet events into trace/log/metric events.
- Acceptance Criteria:
  - Local collector config documented
  - Event fields mapped
  - Privacy class preserved
- Stop Condition: Telemetry leaks sensitive content.

## P2 — Sandbox External Agents

### HV2-P2-007 — Create Sandbox Fixture Repos

- Agent: quartermaster
- Mission: Add tiny fixture repos for safe OpenHands/Codex/Claude testing.
- Acceptance Criteria:
  - Includes clean repo, broken test repo, scope drift trap repo
  - No secrets
  - Reset script exists
- Stop Condition: Fixture accesses live repo.

### HV2-P2-008 — OpenHands Sandbox Trial

- Agent: chainbreaker
- Mission: Evaluate OpenHands only against copied fixtures.
- Acceptance Criteria:
  - L0-L2 results recorded
  - Tool use logged
  - Scope drift scored
- Stop Condition: Agent attempts live repo mutation.

## P3 — Governance Polish

### HV2-P3-009 — Add Playbook Index

- Agent: archivist
- Mission: Create a playbook index mapping playbooks to runtime gates.
- Acceptance Criteria:
  - Lists playbooks
  - Defines authority hierarchy
  - Flags stale/missing playbooks
- Stop Condition: Conflicting source-of-truth rules.
