# GitHub Borrow Shortlist for Chromatic Harness v2

## Executive Recommendation

Borrow narrow, proven infrastructure. Do not pivot the harness around any external project. The harness remains the source of truth; external repos are adapters, engines, or sandbox subjects.

## Ranked Shortlist

| Rank | Project | Action | Fit | Use For | Main Risk |
|---:|---|---|---:|---|---|
| 1 | LangGraph | Use / adapter | 92 | Durable workflow runtime, state machine execution, human-in-loop patterns | Adds dependency and conceptual weight |
| 2 | OpenTelemetry Collector | Use / adapter | 88 | Magnet telemetry, traces, metrics, logs | Requires event model mapping |
| 3 | OpenHands | Sandbox only | 86 | Testing external software agents against fixtures | Must not touch live repos first |
| 4 | n8n | Optional adapter | 72 | Webhooks, automations, notifications | License/security/brain-creep concerns |

## Borrow vs Build

### Borrow

- Runtime graph/state-machine patterns from LangGraph.
- Observability transport from OpenTelemetry.
- External agent sandbox testing pattern from OpenHands.
- Webhook/notification automation from n8n only if needed.

### Build Custom

- CMP mission packet semantics.
- Confidence gate scoring.
- Magnet meaning and inflection points.
- Bead structure and queue logic.
- Chromatic governance and routing.
- Console information architecture.

## Integration Order

1. LangGraph adapter after smoke tests pass.
2. OpenTelemetry adapter after Magnet event schema stabilizes.
3. OpenHands sandbox after fixture repos exist.
4. n8n only after core loop is stable.

## Guardrails

- External repos cannot become the source of truth.
- External agents cannot mutate live repos until Sandbox Lab stages L0-L4 pass.
- Adapters must be replaceable.
- All borrowed systems must report back into CMP, Magnets, and Beads.
