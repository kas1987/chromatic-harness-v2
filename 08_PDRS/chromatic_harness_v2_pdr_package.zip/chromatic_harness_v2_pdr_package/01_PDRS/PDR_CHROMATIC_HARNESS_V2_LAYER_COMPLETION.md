# PDR: Chromatic Harness v2 Layer Completion and GitHub Borrow Plan

## 1. Executive Summary

Chromatic Harness v2 is a clean-reset autonomous workflow harness built around governed mission packets, deterministic observability probes, provider/tool routing, agent execution, structured task intake, and a frontend console.

The current scaffold is directionally correct, but it needs operational proof. This PDR defines the next implementation package required to make the Harness v2 spine runnable, testable, visible, and safe for external agent integration.

## 2. Objective

Build the minimum reliable Harness v2 loop:

```text
User Intent / GO
-> CMP Mission Packet
-> Runtime Orchestrator
-> Magnet Events
-> Confidence Gate
-> Bead Creation
-> Frontend Console Visibility
-> Next Mission Recommendation
```

## 3. Problem Statement

The repo has strong design artifacts but still risks:

- duplicated governance without runtime enforcement
- frontend plans without a clickable command surface
- external agent adoption before sandbox proof
- insufficient smoke tests for API and runtime behavior
- schema drift between protocols, runtime, logs, and UI
- too much conceptual expansion before E2E validation

## 4. Scope

### In Scope

- Layer completion requirements
- E2E smoke-test plan
- Schema/package validation
- Minimal frontend console definition
- LangGraph adapter evaluation
- OpenTelemetry adapter evaluation
- OpenHands sandbox evaluation
- Agent handoff packets
- Governance gates and stop conditions

### Out of Scope

- Production deployment
- Live autonomous repo mutation
- Multi-agent swarm execution
- Cloud spend optimization beyond initial routing constraints
- Full authentication and RBAC beyond placeholder design notes

## 5. Target Architecture

| Layer | Responsibility | Completion Target |
|---|---|---|
| Source of Truth | Authoritative manifest, decisions, glossary, state | Add state, roadmap, validation matrix |
| Protocols | CMP, Beads, Magnets, MCP contracts | Add validators and examples |
| Runtime | API, orchestrator, magnets, confidence | Prove mission-event-bead loop |
| Agents | Registry and lead synthesis | Add capability matrix and promotion rules |
| Playbooks | GO mode, orchestration, sandbox, routing | Add playbook index and cross-links |
| Frontend Console | Visibility and action surface | Build 4-panel MVP |
| Deployment | Docker and env setup | Add healthcheck and smoke command |
| Runtime Logs | Audit/event trail | Add JSONL schemas and append-only rules |
| Sandbox Lab | Safe external agent testing | Run fixture-based evals |
| Handoffs | Agent/reviewer packets | Add packet generators |

## 6. External GitHub Additions

| Candidate | Role | Decision |
|---|---|---|
| LangGraph | Runtime state machine and durable agent flow | Add first |
| OpenTelemetry Collector | Magnet telemetry backend | Add second |
| OpenHands | Sandbox Lab external code-agent testing | Add third, sandbox only |
| n8n | Optional automation/webhook adapter | Evaluate later, never core brain |

## 7. MVP Deliverables

1. `scripts/smoke_harness_api.py`
2. `scripts/validate_harness_package.py`
3. `docs/VALIDATION_MATRIX.md`
4. `docs/SYSTEM_STATE.md`
5. `05_FRONTEND_CONSOLE` MVP panels:
   - Mission Dashboard
   - Magnet Event Stream
   - Confidence/Risk Panel
   - Beads Queue
6. `02_RUNTIME/adapters/langgraph_adapter.py`
7. `02_RUNTIME/telemetry/otel_adapter.py`
8. `11_SANDBOX_LAB/evals/openhands_fixture_eval.md`

## 8. Acceptance Criteria

- A mission can be created via API and stored.
- A magnet event can be attached to a mission.
- A bead can be created from a mission/event outcome.
- The console can display mission, event, confidence/risk, and bead state.
- Protocol schemas can be loaded and validated.
- Package index can be compared against actual repo files.
- External agents are tested only against copied fixture repos.
- Human-gate and stop-condition rules are visible in execution outputs.

## 9. Risks

| Risk | Severity | Mitigation |
|---|---:|---|
| Over-scaffolding | High | Require E2E smoke test before new layers |
| Unsafe external agent integration | High | Sandbox Lab only; no live repo access initially |
| Schema drift | Medium | Add validator and CI check |
| Frontend/backend mismatch | Medium | API contract snapshot and generated sample data |
| Tool-call explosion | Medium | Cost/tool budget Magnet and stop conditions |
| n8n becoming hidden brain | Medium | Treat n8n as adapter only |

## 10. Recommended Sprint

### Sprint Name

Harness v2 Spine Proof Sprint

### Sprint Goal

Prove the spine from mission creation through event capture and bead output, then expose it in the console.

### Sprint Exit Gate

No additional repos or agents are integrated until the smoke test and schema validation pass locally.
