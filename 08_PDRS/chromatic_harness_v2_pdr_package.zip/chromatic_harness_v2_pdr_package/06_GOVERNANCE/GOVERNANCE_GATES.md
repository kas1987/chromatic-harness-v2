# Governance Gates for Harness v2 Completion

## Source-of-Truth Gate

Before implementing a task, the agent must identify the controlling source:

1. Manifest / protocol spec
2. Schema
3. Playbook
4. PDR
5. README / comments

If sources conflict, halt and route to auditor.

## Evidence Gate

No task is ready unless it has:

- source files
- target files
- acceptance criteria
- stop condition
- validation method

## Safety Gate

Human approval is required for:

- deleting files
- live repo mutation by external agents
- production deployment
- secret handling
- public release
- broad architecture replacement

## Runtime Gate

Runtime work must pass:

- smoke test
- schema validation
- confidence decision visibility
- event/log visibility

## Sandbox Gate

External agents must pass:

- L0 dry reasoning
- L1 read-only fixture
- L2 simulated patch fixture
- L3 container test fixture
- L4 draft PR against noncritical branch

No external agent gets live repo autonomy before these pass.

## Stop Conditions

Stop immediately if:

- confidence falls below threshold
- scope is unclear
- source-of-truth conflict appears
- secret or credential is detected
- external agent reaches outside fixture path
- tests fail in unrelated area
- tool loop repeats without new evidence
