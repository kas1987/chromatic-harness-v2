# Agent Handoff: Auditor

## Task ID
HV2-P0-002

## Mission
Add package and schema validation for source-of-truth protocols.

## Source Files
- `PACKAGE_FILE_INDEX.txt`
- `01_PROTOCOLS/**`
- `00_SOURCE_OF_TRUTH/**`

## Allowed Actions
- Add validation script
- Add validation matrix
- Report missing files or invalid schemas

## Blocked Actions
- Do not silently alter protocols
- Do not resolve source-of-truth contradictions without decision log entry

## Acceptance Criteria
- JSON schemas parse
- YAML files parse
- Indexed files exist
- Missing files are reported with path and severity

## Stop Condition
Stop on conflicting protocol definitions.
