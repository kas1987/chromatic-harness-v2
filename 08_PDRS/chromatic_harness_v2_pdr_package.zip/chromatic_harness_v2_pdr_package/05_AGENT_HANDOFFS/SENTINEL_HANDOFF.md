# Agent Handoff: Sentinel

## Task ID
HV2-P0-001

## Mission
Add an API smoke test that proves the Harness v2 spine can create and retrieve missions, magnet events, and beads.

## Source Files
- `02_RUNTIME/api/main.py`
- `02_RUNTIME/api/models.py`
- `09_DEPLOYMENT/docker-compose.yml`

## Allowed Actions
- Add test/smoke script
- Add docs for running smoke test
- Add minimal fixture payloads

## Blocked Actions
- Do not change public API semantics without auditor review
- Do not add external agent integration

## Acceptance Criteria
- Script exits zero only when full spine works
- Script prints mission id, event id, bead id
- Failure output is clear

## Stop Condition
Stop if endpoint models are missing or inconsistent.
