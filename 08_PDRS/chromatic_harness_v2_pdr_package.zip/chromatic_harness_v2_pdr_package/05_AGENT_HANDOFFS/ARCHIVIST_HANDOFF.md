# Agent Handoff: Archivist

## Task ID
HV2-P3-009

## Mission
Create a playbook index and source-of-truth map so agents know which governance artifact controls which decision.

## Allowed Actions
- Add `PLAYBOOK_INDEX.md`
- Add source-of-truth hierarchy
- Add stale-playbook review table

## Blocked Actions
- Do not duplicate full playbooks
- Do not invent new policy outside manifest/protocol authority

## Acceptance Criteria
- Every playbook has domain, owner, scope, and runtime gate mapping
- Conflicts are flagged, not merged silently

## Stop Condition
Stop on contradictory rules between manifest, specs, and playbooks.
