# Agent Handoff: Chainbreaker

## Task ID
HV2-P1-005 / HV2-P2-008

## Mission
Evaluate LangGraph and OpenHands as bounded integrations without allowing architecture lock-in or live repo mutation.

## Allowed Actions
- Build adapter prototype
- Run fixture-only external agent tests
- Record integration burden

## Blocked Actions
- Do not connect OpenHands to live repo
- Do not make LangGraph the source of truth
- Do not bypass CMP confidence gates

## Acceptance Criteria
- Adapter remains replaceable
- Fixture run evidence captured
- Risks and failures logged as Beads

## Stop Condition
Stop if an external system attempts uncontrolled tool use or live repo mutation.
