# Agent Handoff: Cartographer

## Task ID
HV2-P0-003

## Mission
Build the minimal frontend console panels for live Harness v2 visibility.

## Source Files
- `05_FRONTEND_CONSOLE/src/app/page.tsx`
- `05_FRONTEND_CONSOLE/src/app/layout.tsx`
- `05_FRONTEND_CONSOLE/README.md`

## Required Panels
- Mission Dashboard
- Magnet Event Stream
- Confidence/Risk Panel
- Beads Queue

## Allowed Actions
- Add components
- Add API client helper
- Add loading/error states

## Blocked Actions
- Do not add auth yet
- Do not redesign the full UI system
- Do not hardcode production endpoints

## Acceptance Criteria
- Console reads `NEXT_PUBLIC_API_URL`
- Console renders mission and bead data
- Console shows empty state gracefully

## Stop Condition
Stop if API contract is unstable.
