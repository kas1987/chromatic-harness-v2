# Implementation Roadmap

## Phase 0 — Freeze Expansion

Goal: prevent scaffold creep.

- Do not add new major layers.
- Do not connect external agents to live repos.
- Do not add n8n automations as core harness logic.

Exit Gate: PDR package accepted and task queue loaded.

## Phase 1 — Spine Proof

Goal: prove API and state loop.

Tasks:

1. API smoke test
2. Package/schema validator
3. Runtime event logging check

Exit Gate:

```text
Mission -> Event -> Bead -> List views all pass locally
```

## Phase 2 — Console MVP

Goal: make the harness visible.

Panels:

1. Mission Dashboard
2. Magnet Event Stream
3. Confidence/Risk Panel
4. Beads Queue

Exit Gate: frontend displays live API state.

## Phase 3 — Runtime Adapter

Goal: move from skeleton orchestration to stateful workflow.

- Add LangGraph adapter.
- Map mission packet to graph state.
- Emit Magnet events at graph nodes.
- Produce confidence decision and bead output.

Exit Gate: one sample graph run completes locally.

## Phase 4 — Observability Adapter

Goal: make Magnets operationally useful.

- Add OpenTelemetry adapter.
- Preserve privacy class.
- Emit local traces/logs.
- Keep Magnet schema as source of truth.

Exit Gate: one mission run produces queryable telemetry.

## Phase 5 — Sandbox External Agents

Goal: evaluate OpenHands or similar agents safely.

- Create fixture repos.
- Run L0-L2 evals.
- Record results as Beads.

Exit Gate: external agent earns or fails promotion based on evidence.
