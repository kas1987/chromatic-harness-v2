# Validation Matrix

| Validation | Target | Command / Method | Required For |
|---|---|---|---|
| API health | `/health` returns ok | `curl localhost:8787/health` | All runtime work |
| Mission create | `POST /missions` | Smoke script | Spine proof |
| Event create | `POST /missions/{id}/events` | Smoke script | Magnet proof |
| Bead create | `POST /beads` | Smoke script | Queue proof |
| Schema load | JSON/YAML parse | Package validator | Protocol proof |
| Package index | Paths exist | Package validator | Repo integrity |
| Frontend API | Console fetches API | Browser/manual | Console MVP |
| Docker backend | API starts in compose | `docker compose up chromatic-api` | Deployment proof |
| Docker console | Next app starts in compose | `docker compose up chromatic-console` | UI proof |
| Sandbox fixture | No live repo mutation | Fixture eval | External agent safety |

## Minimum Green Bar

The sprint is complete only when these pass:

- API health
- Mission create
- Event create
- Bead create
- Mission list
- Bead list
- Schema load
- Package index check
