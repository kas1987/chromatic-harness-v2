# CHV2 Pre-Session Context Pack

This pack contains repo-ready governance artifacts for Chromatic Harness v2.

## Files

| File | Purpose |
|---|---|
| `PDR-CHV2-001_PRE_SESSION_CONTEXT_AND_EXECUTION_FLOW_CONSOLIDATION.md` | Main PDR. |
| `00_SOURCE_OF_TRUTH/HARNESS_EXECUTION_FLOW.md` | Canonical execution flow. |
| `docs/governance/PRE_SESSION_CONTEXT_POLICY.md` | Tiered context loading policy. |
| `docs/BEADS_OBJECT_MODEL.md` | Beads object model. |
| `docs/governance/OPENROUTER_BROKER_POLICY.md` | OpenRouter governance policy. |
| `beads/ROUTER_VALIDATION_BEADS.md` | Copy-ready router validation bead backlog. |
| `AGENTS_WRAPPER_PROPOSAL.md` | Proposed simplified AGENTS.md. |
| `CLAUDE_WRAPPER_PROPOSAL.md` | Proposed simplified CLAUDE.md. |

## Suggested install

Copy the contents into the Harness v2 repo root, then open a branch:

```bash
git checkout -b pdr/chv2-pre-session-flow
cp -r chv2_pre_session_pack/* .
git status --short
```

Review wrapper proposals before replacing existing `AGENTS.md` or `CLAUDE.md`.
