# Harness Boot Context

> Operational snapshot for a clean Chromatic Harness v2 session. This is not permanent canon.

## Session Status

| Field | Value |
|---|---|
| Generated At | 2026-05-30T01:24:59.362061+00:00 |
| Manifest Generated At | 2026-05-30T01:24:57.124846+00:00 |
| Rebuild Mode | hard |
| Repo Root | /mnt/data/chv2_context_rebuild_pack |
| Context Risk | green |

## Active Mission

Select the highest-priority active bead or mission. Do not infer from old chat history.

## Git State

```text
Branch: unknown
Status:
clean or unavailable
Last Commit: unknown
```

## Active Handoff

```text
Latest pointer exists: False
Latest pointer path: None
Handoff path: None
```

## Active Beads

```text
bd unavailable or no ready output
```

## Allowed Pre-Session Context

### Always Load

- .agents/context/BOOT_CONTEXT.md
- .agents/handoffs/latest.json
- active handoff referenced by latest.json
- selected bd issue details
- git branch/status summary

### Load Only If Relevant

- AGENT_OPERATIONS.md
- docs/governance/PRE_SESSION_CONTEXT_POLICY.md
- docs/governance/CONTEXT_REBUILD_POLICY.md
- docs/governance/OPENROUTER_BROKER_POLICY.md
- docs/BEADS_OBJECT_MODEL.md
- 04_PLAYBOOKS/*.md for selected mission only
- 09_DEPLOYMENT/config/routing/*.yaml for routing work only

### Never Auto-Load

- ~/.claude/projects/**/*.jsonl
- 07_LOGS_AND_AUDIT/**/*.jsonl
- traces/**/*.jsonl
- old handoff chains
- archive folders
- entire docs folder
- entire repository tree
- full deployment guide unless deployment is active mission

## Context Audit Findings

No audit findings available.

## Next Action

Restart from .agents/context/BOOT_CONTEXT.md and selected bead only.

## Stop Conditions

Stop and rebuild again if:

- Context reaches 75%+.
- Required task context is missing.
- Agent starts reading unrelated logs, archives, or old handoffs.
- Active bead/mission is unclear.
- A destructive action is required.

## Operating Reminder

Use this boot packet to start clean. Then load only the selected bead, required source files, and the smallest relevant governance document.
