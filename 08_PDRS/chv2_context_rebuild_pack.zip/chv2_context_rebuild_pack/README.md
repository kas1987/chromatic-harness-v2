# CHV2 Context Rebuild and Trim Pack

This pack adds a controlled context-reset layer for Chromatic Harness v2.

It is designed for situations where the active model context is too full, duplicated, stale, or contaminated by long chat history. It does not delete project knowledge. It externalizes useful state into repo artifacts, audits context-bloat risks, and produces a clean `BOOT_CONTEXT.md` for the next session.

## Files

```text
chv2_context_rebuild_pack/
├── README.md
├── PDR-CHV2-002_CONTEXT_REBUILD_AND_TRIM_SYSTEM.md
├── scripts/
│   ├── context_trim_audit.py
│   ├── context_rebuild.py
│   └── new_session_bootstrap.py
├── docs/
│   └── governance/
│       └── CONTEXT_REBUILD_POLICY.md
├── templates/
│   └── BOOT_CONTEXT_TEMPLATE.md
└── beads/
    └── CONTEXT_REBUILD_BEADS.md
```

## Install

Copy the contents into the root of `chromatic-harness-v2`.

Recommended target paths:

```text
scripts/context_trim_audit.py
scripts/context_rebuild.py
scripts/new_session_bootstrap.py
docs/governance/CONTEXT_REBUILD_POLICY.md
templates/BOOT_CONTEXT_TEMPLATE.md
PDR-CHV2-002_CONTEXT_REBUILD_AND_TRIM_SYSTEM.md
beads/CONTEXT_REBUILD_BEADS.md
```

## Quick usage

```bash
python scripts/context_trim_audit.py --root .
python scripts/context_rebuild.py --root . --mode hard
python scripts/new_session_bootstrap.py --root .
```

Outputs are written to:

```text
.agents/context/
├── context_trim_audit.json
├── context_rebuild_manifest.json
├── context_rebuild_summary.md
└── BOOT_CONTEXT.md
```

## Operating rule

If context usage is red, stop expanding the discussion. Compact, rebuild, and restart from `BOOT_CONTEXT.md`.

Suggested thresholds:

| Level | Context usage | Action |
|---|---:|---|
| Green | 0-40% | Normal work |
| Yellow | 40-60% | Prefer focused docs only |
| Orange | 60-75% | Compact soon; avoid broad reads |
| Red | 75%+ | Hard compact/rebuild before more work |
