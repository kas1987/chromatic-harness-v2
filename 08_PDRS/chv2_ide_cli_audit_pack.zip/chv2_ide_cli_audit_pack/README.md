# CHV2 IDE + CLI Audit Pack

This pack adds a repo-owned audit and monitoring layer for Chromatic Harness v2 so Cursor, Claude Code, VS Code, terminal shells, and future agents all follow the same operational standard.

## Install

Copy the contents of this pack into the root of `chromatic-harness-v2`.

Recommended order:

```bash
cp -r scripts docs .cursor .vscode beads .github /path/to/chromatic-harness-v2/
```

Then run:

```bash
python scripts/daily_harness_audit.py --root . --report
```

## Included

```text
PDR-CHV2-003_IDE_CLI_AUDIT_AND_DAILY_MONITORING.md
scripts/daily_harness_audit.py
scripts/audit_ide_parity.py
scripts/audit_instruction_drift.py
docs/governance/IDE_CLI_PARITY_POLICY.md
docs/governance/DAILY_AUDIT_RUNBOOK.md
.cursor/rules/harness-audit.mdc
.vscode/tasks.json
beads/IDE_CLI_AUDIT_BEADS.md
.github/workflows/harness-daily-audit.yml
```

## Core principle

Every IDE and CLI may wrap the workflow, but no IDE owns the workflow. The repo owns the workflow.

## Daily command

```bash
python scripts/daily_harness_audit.py --root . --report
```

## Expected outputs

```text
.agents/audits/latest_audit.json
.agents/audits/latest_audit_summary.md
.agents/audits/daily/YYYY-MM-DD_AUDIT_REPORT.md
.agents/audits/findings/open_findings.jsonl
```
