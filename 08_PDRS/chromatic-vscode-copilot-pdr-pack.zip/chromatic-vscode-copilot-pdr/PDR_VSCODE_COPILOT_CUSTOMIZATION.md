# PDR: VS Code Copilot Customization Layer for Chromatic Harness

| Field | Value |
|---|---|
| PDR ID | PDR-VSCODE-COPILOT-CUSTOMIZATION-001 |
| Status | Draft for adoption |
| Owner | Human Owner / Chromatic Harness |
| Created | 2026-05-30 |
| Scope | VS Code, GitHub Copilot customizations, agents, prompts, skills, MCP, hooks |
| Decision Type | Repo operating model / AI development governance |

## 1. Executive Decision

Adopt VS Code Copilot customization as the repo cockpit for Chromatic Harness, using a layered model:

```text
ChromaticTrees = law
Playbooks = doctrine
VS Code custom agents = role execution
Prompt files = repeatable workflows
Instruction files = scoped conventions
Agent skills = reusable capabilities
MCP = controlled external access
Hooks/CI = deterministic enforcement
Logs = audit trail
```

The implementation must prevent the primary failure mode: overpowered AI agents wandering through a repo without scope, confidence scoring, validation, or state updates.

## 2. Problem

The repo currently needs a consistent way to let AI tools operate without repeatedly rediscovering context or improvising rules.

Observed problems:

- Repo rules can be duplicated across too many files.
- Agents can overuse tools and broaden scope.
- "GO" commands need a deterministic operating path.
- Implementation, review, QA, and docs roles need separation.
- VS Code customizations need to align with ChromaticTrees, not compete with it.

## 3. Goals

1. Provide a standard VS Code AI operating layer.
2. Establish role-specific custom agents with constrained tools.
3. Use prompt files for repeatable workflows.
4. Use scoped instruction files for language/domain-specific rules.
5. Add starter skills for reusable repo operations.
6. Add MCP and hooks as gated, controlled capabilities.
7. Preserve auditability through logs, state files, and decision records.

## 4. Non-Goals

- This PDR does not implement production deployment automation.
- This PDR does not authorize destructive operations.
- This PDR does not replace CI.
- This PDR does not replace human approval for high-risk changes.
- This PDR does not assume every repo has the same stack.

## 5. Adopted VS Code Capabilities

| Capability | Adopt? | Use |
|---|---:|---|
| `.github/copilot-instructions.md` | Yes | Short global repo alignment |
| `.github/instructions/*.instructions.md` | Yes | Scoped file/domain conventions |
| `.github/prompts/*.prompt.md` | Yes | Repeatable one-shot workflows |
| `.github/agents/*.agent.md` | Yes | Persistent role-specific agents |
| `.github/skills/*/SKILL.md` | Yes | Portable reusable capabilities |
| `.vscode/mcp.json` | Yes, gated | Controlled external tool access |
| Hooks | Experimental | Deterministic guardrails and logging |
| Dev Container | Yes | Reproducible local environment |

## 6. Required Files

```text
CHROMATIC_TREES.md
WORKTREE_MAP.json
AGENT_HANDOFF_QUEUE.md
SPRINT_STATE.md
DECISION_LOG.md
RISK_REGISTER.md
RUN_LOG.jsonl
.github/copilot-instructions.md
.github/instructions/*.instructions.md
.github/prompts/*.prompt.md
.github/agents/*.agent.md
.github/skills/*/SKILL.md
.vscode/settings.json
.vscode/extensions.json
.vscode/tasks.json
.vscode/mcp.json
.devcontainer/devcontainer.json
docs/vscode-copilot-adoption-guide.md
docs/agent-operating-model.md
docs/hook-policy.md
scripts/validate_chromatic_vscode_pack.py
```

## 7. Governance Rules

### 7.1 Source-of-Truth Hierarchy

1. `CHROMATIC_TREES.md` defines repo tree rules.
2. `WORKTREE_MAP.json` provides machine-readable repo structure.
3. `SPRINT_STATE.md` defines the active objective.
4. `AGENT_HANDOFF_QUEUE.md` defines ordered next work.
5. `.github/copilot-instructions.md` points Copilot toward governance.
6. Agent files define role behavior, not repo law.
7. Hooks, scripts, and CI enforce rules.

### 7.2 No Duplicated Law

Do not copy the full repo governance doctrine into every agent. Agents should reference the source files and keep role instructions short.

### 7.3 Confidence Gate

Before mutation, an agent must score:

| Factor | Weight |
|---|---:|
| Objective clarity | 20% |
| Scope clarity | 20% |
| Evidence quality | 20% |
| Reversibility | 10% |
| Tool fit | 10% |
| Risk awareness | 10% |
| Testability | 10% |

Allowed action bands:

| Score | Behavior |
|---:|---|
| 90-100 | Execute normally within scope |
| 75-89 | Execute with normal logging |
| 60-74 | Execute only if reversible and low risk |
| 40-59 | Plan only; do not mutate |
| 0-39 | Halt and escalate |

### 7.4 Human Gates

Human approval is required for:

- Production deployment
- Secret handling
- Deleting files, branches, databases, or infrastructure
- Major architecture changes
- Cross-repo mutation
- Public release
- Costly external API use
- Irreversible actions

## 8. Agent Model

| Agent | Primary Job | Tool Posture |
|---|---|---|
| Chromatic Orchestrator | Select next task and dispatch | Mostly read + agent handoff |
| Chromatic Planner | Produce implementation plan | Read-only |
| Repo Scout | Locate context and relevant files | Read-only search |
| Feature Builder | Implement scoped changes | Edit + targeted terminal |
| Code Reviewer | Review diffs and defects | Read/diff |
| QA Tester | Run validation | Terminal/test focused |
| Security Auditor | Find security risk | Read-only / limited terminal |
| Docs Scribe | Update docs and state | Docs/state edit |
| Repo Janitor | Tree hygiene cleanup | Gated edit |
| Incident Commander | Contain failures | Read-only diagnosis |

## 9. Handoff Policy

Default all handoffs to `send: false` until the harness shows repeated successful runs.

Permitted handoff chain:

```text
Orchestrator -> Planner -> Feature Builder -> Code Reviewer -> QA Tester -> Docs Scribe
```

Any failure can hand off to:

```text
Incident Commander
```

## 10. MCP Policy

Approved starter MCP classes:

- GitHub MCP for issues, PRs, repo metadata.
- Playwright/browser MCP for UI validation.
- Filesystem MCP only if scoped to the workspace.
- Docker MCP only after local validation gates are added.

Do not enable cloud provider MCP, production DB MCP, or secret management MCP without a separate PDR.

## 11. Hook Policy

Start hooks in observe/report mode only.

Stage progression:

1. Report only.
2. Warn/block known dangerous actions.
3. Auto-format safe file types.
4. Auto-fix only after incident-free usage.

## 12. Implementation Plan

### Phase 1 - Install Baseline

- Add global Copilot instructions.
- Add scoped instruction files.
- Add prompt files.
- Add custom agents.
- Add governance docs.
- Add validation script.

### Phase 2 - Controlled GO Mode

- Use `AGENT_HANDOFF_QUEUE.md` and `SPRINT_STATE.md` as the GO-mode source.
- Orchestrator selects one task.
- Confidence gate required before mutation.
- Handoffs remain visible and not auto-submitted.

### Phase 3 - Skills and MCP

- Add reusable skills.
- Add MCP config with comments and disabled risky paths.
- Add Playwright/browser validation where useful.

### Phase 4 - Hooks and CI Enforcement

- Add report-only hooks.
- Add repo tree validator.
- Add CI checks for required files.

## 13. Acceptance Criteria

- [ ] Required files exist.
- [ ] Copilot instructions point to ChromaticTrees.
- [ ] At least 8 role-specific agents exist.
- [ ] Agents have constrained tool posture.
- [ ] Prompt files cover PDR, PR, audit, testing, and sprint summary.
- [ ] Scoped instruction files exist for governance, frontend, backend, testing, and docs.
- [ ] Validation script passes.
- [ ] No agent has unrestricted destructive authority.
- [ ] Handoffs default to `send: false`.
- [ ] Docs explain adoption, usage, and risks.

## 14. Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---:|---:|---|
| Agent scope creep | High | High | Tool limits, confidence gate, stop conditions |
| Duplicated governance | Medium | Medium | Single source of truth hierarchy |
| Hook damage | Medium | High | Report-only first |
| MCP overreach | Medium | High | Gated MCP policy |
| Context bloat | High | Medium | Short global instructions and scoped files |
| Human gate bypass | Medium | High | Explicit human gate rules |

## 15. Rollback

Rollback is simple:

1. Remove `.github/agents`, `.github/prompts`, `.github/instructions`, `.github/skills`.
2. Remove `.vscode/mcp.json` if MCP causes issues.
3. Keep `CHROMATIC_TREES.md` and governance logs if already useful.
4. Disable hooks before deleting them.

## 16. Decision

Adopt this package as the standard VS Code Copilot customization scaffold for Chromatic Harness repos.
