# Repo Audit

Audit the repo for structure, scattered files, duplicate governance, missing validation, and agent-readiness.

Output:

- Findings ranked by severity
- Evidence
- Recommended fixes
- File movement plan if needed
- Risks
- Next queue items
