# Sprint Summary

Summarize current sprint state.

Read:

- `SPRINT_STATE.md`
- `AGENT_HANDOFF_QUEUE.md`
- `DECISION_LOG.md`
- `RISK_REGISTER.md`

Output:

- Current objective
- Completed work
- Open blockers
- Next best task
- Recommended agent
- Confidence and risk
