# Create PDR

Create a Project Design Record for the requested change.

Include:

- Executive decision
- Problem
- Goals and non-goals
- Proposed architecture
- Required files
- Risks
- Rollback
- Acceptance criteria
- Implementation phases

Follow Chromatic Harness governance and reference `CHROMATIC_TREES.md` when repo structure is involved.
