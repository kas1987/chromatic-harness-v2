# Prepare PR

Prepare a PR summary from current changes.

Include:

- What changed
- Why it changed
- Files touched
- Validation performed
- Risks and limitations
- Rollback notes
- Reviewer checklist
