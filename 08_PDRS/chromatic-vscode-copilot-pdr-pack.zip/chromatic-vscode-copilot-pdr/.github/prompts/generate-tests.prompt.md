# Generate Tests

Generate or recommend targeted tests for the selected change.

Include:

- Behavior under test
- Edge cases
- Regression cases
- Minimal test files to add/update
- Commands to run
- Residual risk if tests cannot be run
