# Chromatic Harness Copilot Instructions

This repo follows Chromatic Harness governance.

Before modifying code:

1. Read `CHROMATIC_TREES.md`.
2. Check `SPRINT_STATE.md`.
3. Check `AGENT_HANDOFF_QUEUE.md`.
4. Confirm scope and allowed files.
5. Score confidence before mutation.
6. Prefer the smallest safe next step.
7. Validate with available tests or targeted checks.
8. Update state/log files when repo state changes.

Do not invent repo structure.
Do not duplicate governance rules.
Do not modify secrets, infrastructure, CI, deployment, or public release files without explicit human approval.
Do not continue when confidence is below the mutation threshold.
