---
applyTo: "**/*"
---

# Repo Governance Instructions

- `CHROMATIC_TREES.md` is the source of truth for tree rules.
- Do not add new top-level folders without approval.
- Update `WORKTREE_MAP.json` after structural changes.
- Use mission packets for agent work.
- Stop if user intent conflicts with human gate rules.
