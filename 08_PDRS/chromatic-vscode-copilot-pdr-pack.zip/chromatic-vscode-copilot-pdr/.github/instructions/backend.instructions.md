---
applyTo: "**/*.{py,js,ts,json,yaml,yml,toml,env.example}"
---

# Backend Instructions

- Do not hardcode secrets.
- Preserve configuration boundaries.
- Add validation and error handling for user-controlled inputs.
- Prefer small service functions over large orchestration blobs.
- Do not change database schema, auth, deployment, or secrets without a human gate.
