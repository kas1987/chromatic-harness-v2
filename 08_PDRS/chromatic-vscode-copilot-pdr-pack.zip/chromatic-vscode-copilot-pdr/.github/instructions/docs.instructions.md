---
applyTo: "**/*.md"
---

# Documentation Instructions

- Keep docs decision-ready and structured.
- Use status, owner, scope, risks, and next action where relevant.
- Do not let docs drift from actual repo structure.
- Link to source files rather than duplicating long governance rules.
