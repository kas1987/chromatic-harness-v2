---
applyTo: "**/*.{js,jsx,ts,tsx,css,scss,html}"
---

# Frontend Instructions

- Preserve existing design tokens and component patterns.
- Prefer small composable components.
- Do not create new global CSS without routing it through the approved CSS library.
- Keep accessibility visible: labels, contrast, keyboard path, semantic HTML.
- Validate with targeted build, lint, or UI smoke check where available.
