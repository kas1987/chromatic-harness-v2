---
applyTo: "**/{test,tests,__tests__}/**/*,**/*.{test,spec}.{js,jsx,ts,tsx,py}"
---

# Testing Instructions

- Prefer targeted tests that map to the changed behavior.
- Add regression tests for fixed defects.
- Do not delete failing tests without a documented reason.
- Report what was tested, what was not tested, and residual risk.
