# chromatic-css-library

## Description

CSS library skill for creating, validating, and documenting design-system utilities.

## Trigger

Run this for global CSS library, design tokens, component classes, and UI style scaffolds.

## Inputs

- User objective
- Relevant repo files
- `CHROMATIC_TREES.md`
- `SPRINT_STATE.md`
- `AGENT_HANDOFF_QUEUE.md`

## Output

- Findings or plan
- Confidence score
- Risk level
- Files affected
- Validation recommendation
- Next queue item

## Rules

- Prefer smallest safe next step.
- Do not mutate without scope and confidence.
- Record uncertainty.
- Defer repo structure rules to `CHROMATIC_TREES.md`.
