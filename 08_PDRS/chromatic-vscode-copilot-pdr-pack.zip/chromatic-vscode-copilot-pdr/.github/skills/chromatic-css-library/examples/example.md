# Example Use

User asks for: Run this for global CSS library, design tokens, component classes, and UI style scaffolds.

Expected result:

- Clear scope
- Evidence-backed findings
- Confidence score
- Suggested next task
