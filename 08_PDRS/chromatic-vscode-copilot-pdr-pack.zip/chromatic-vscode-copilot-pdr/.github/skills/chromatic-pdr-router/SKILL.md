# chromatic-pdr-router

## Description

PDR routing skill for turning project design records into scoped queue items and mission packets.

## Trigger

Run this when a PDR needs to become implementation tasks.

## Inputs

- User objective
- Relevant repo files
- `CHROMATIC_TREES.md`
- `SPRINT_STATE.md`
- `AGENT_HANDOFF_QUEUE.md`

## Output

- Findings or plan
- Confidence score
- Risk level
- Files affected
- Validation recommendation
- Next queue item

## Rules

- Prefer smallest safe next step.
- Do not mutate without scope and confidence.
- Record uncertainty.
- Defer repo structure rules to `CHROMATIC_TREES.md`.
