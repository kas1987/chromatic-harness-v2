# Example Use

User asks for: Run this when a PDR needs to become implementation tasks.

Expected result:

- Clear scope
- Evidence-backed findings
- Confidence score
- Suggested next task
