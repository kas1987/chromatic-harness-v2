# Example Use

User asks for: Run this after implementation or before PR preparation.

Expected result:

- Clear scope
- Evidence-backed findings
- Confidence score
- Suggested next task
