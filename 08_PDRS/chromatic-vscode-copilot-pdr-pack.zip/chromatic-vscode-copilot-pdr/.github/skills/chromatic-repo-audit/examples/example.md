# Example Use

User asks for: Run this when asked to audit repo structure, root hygiene, or ChromaticTrees compliance.

Expected result:

- Clear scope
- Evidence-backed findings
- Confidence score
- Suggested next task
