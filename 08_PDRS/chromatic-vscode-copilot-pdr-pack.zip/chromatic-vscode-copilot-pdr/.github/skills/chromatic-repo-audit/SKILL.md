# chromatic-repo-audit

## Description

Repo audit skill for tree hygiene, governance drift, scattered files, and agent-readiness.

## Trigger

Run this when asked to audit repo structure, root hygiene, or ChromaticTrees compliance.

## Inputs

- User objective
- Relevant repo files
- `CHROMATIC_TREES.md`
- `SPRINT_STATE.md`
- `AGENT_HANDOFF_QUEUE.md`

## Output

- Findings or plan
- Confidence score
- Risk level
- Files affected
- Validation recommendation
- Next queue item

## Rules

- Prefer smallest safe next step.
- Do not mutate without scope and confidence.
- Record uncertainty.
- Defer repo structure rules to `CHROMATIC_TREES.md`.
