# Example Use

User asks for: Run this before enabling external access or destructive automation.

Expected result:

- Clear scope
- Evidence-backed findings
- Confidence score
- Suggested next task
