# chromatic-security-review

## Description

Security review skill for secrets, MCP, hooks, dependencies, and unsafe automation.

## Trigger

Run this before enabling external access or destructive automation.

## Inputs

- User objective
- Relevant repo files
- `CHROMATIC_TREES.md`
- `SPRINT_STATE.md`
- `AGENT_HANDOFF_QUEUE.md`

## Output

- Findings or plan
- Confidence score
- Risk level
- Files affected
- Validation recommendation
- Next queue item

## Rules

- Prefer smallest safe next step.
- Do not mutate without scope and confidence.
- Record uncertainty.
- Defer repo structure rules to `CHROMATIC_TREES.md`.
