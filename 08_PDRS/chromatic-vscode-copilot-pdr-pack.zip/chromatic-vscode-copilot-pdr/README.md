# Chromatic VS Code Copilot Customization PDR Pack

This package turns VS Code into a governed Chromatic Harness cockpit using:

- Project Design Record (PDR)
- `.github/copilot-instructions.md`
- Scoped instruction files
- Prompt files
- Custom agents
- Agent skills
- MCP starter config
- Hook policy notes
- Governance and validation scaffolds

## Install

Copy the contents of this folder into the root of the target repo.

Recommended first pass:

```bash
cp -R .github .vscode .devcontainer docs scripts CHROMATIC_TREES.md WORKTREE_MAP.json AGENT_HANDOFF_QUEUE.md SPRINT_STATE.md DECISION_LOG.md RISK_REGISTER.md RUN_LOG.jsonl /path/to/repo/
```

Then open VS Code and run:

```text
Chat: Open Customizations
```

## Operating principle

ChromaticTrees remains the law. VS Code Copilot customizations are the cockpit. Agents do not invent structure; they defer to repo governance, score confidence, and operate through scoped mission packets.
