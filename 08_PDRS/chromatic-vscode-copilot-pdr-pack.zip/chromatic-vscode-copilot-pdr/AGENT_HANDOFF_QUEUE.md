# Agent Handoff Queue

## Queue Rules

- One active implementation task at a time.
- Orchestrator must score confidence before dispatch.
- Builder must stay within allowed files.
- Reviewer must verify scope and correctness.
- QA must validate before Docs Scribe closes the loop.

## Current Queue

| ID | Priority | Title | Agent | Status | Confidence Target | Risk |
|---|---:|---|---|---|---:|---|
| VSCAI-001 | 1 | Install VS Code Copilot customization baseline | Chromatic Orchestrator | Ready | 85 | Medium |
| VSCAI-002 | 2 | Validate required governance files | QA Tester | Ready | 90 | Low |
| VSCAI-003 | 3 | Tune agents for repo-specific stack | Chromatic Planner | Backlog | 75 | Medium |
| VSCAI-004 | 4 | Enable MCP servers selectively | Security Auditor | Backlog | 80 | High |
| VSCAI-005 | 5 | Convert hooks from report-only to block mode | Incident Commander | Backlog | 90 | High |

## Mission Packet Template

```md
# Mission Packet

## Task ID

## Objective

## Allowed Files

## Forbidden Files

## Allowed Tools

## Tool Budget

## Risk Level

## Confidence Score

## Definition of Done

## Stop Conditions

## Required Output
```
