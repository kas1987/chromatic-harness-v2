# ChromaticTrees

ChromaticTrees is the source of truth for repo structure, file ownership, and tree hygiene.

## Core Rules

1. Project-owned folders should be intentional, named, and documented.
2. The repo root must stay clean.
3. Scattered files are defects unless explicitly temporary.
4. Generated artifacts must live in generated/output folders.
5. Agents must not invent folder conventions.
6. Any structural change must update `WORKTREE_MAP.json`.
7. Any repeated confusion becomes a documented learning.

## VS Code / Agent Bridge

VS Code agents, Copilot instructions, prompt files, and skills defer to this file.

Agent behavior:

- Read this before repo-structure work.
- Do not create new top-level folders without approval.
- Do not move files without updating references.
- Stop and escalate if tree rules conflict with user instruction.

## Worktree Zones

| Zone | Purpose | Owner |
|---|---|---|
| `.github/` | AI customization, workflows, repo governance | Harness |
| `.vscode/` | Workspace config, tasks, MCP config | Harness |
| `.devcontainer/` | Reproducible development environment | Harness |
| `docs/` | Human-readable operating docs | Docs Scribe |
| `scripts/` | Validation and utility scripts | Builder / QA |
| `src/` | Application source code | Project |
| `tests/` | Automated tests | QA |

## Health Scorecard

| Check | Target |
|---|---:|
| Root clutter | 0 unowned files |
| Required governance files | 100% present |
| Agent files validated | 100% present |
| State logs updated | Every meaningful run |
| Unscoped agent edits | 0 |
