# Sprint State

| Field | Value |
|---|---|
| Sprint | VS Code Copilot Customization Baseline |
| Status | Active |
| Primary Goal | Install governed VS Code AI customization layer |
| Current Objective | Adopt files, validate structure, then tune per repo |
| Human Gate | Required before enabling destructive hooks or broad MCP access |

## Active Definition of Done

- Baseline files copied into repo.
- Validation script passes.
- Copilot instructions loaded.
- Agent roles visible in VS Code.
- Handoffs remain `send: false`.
- No destructive automation enabled.
