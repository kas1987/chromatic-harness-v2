# Decision Log

| Date | Decision | Reason | Owner |
|---|---|---|---|
| 2026-05-30 | Adopt VS Code Copilot customization as Chromatic Harness cockpit | Gives agents role separation, reusable prompts, scoped instructions, and governance alignment | Human Owner |
| 2026-05-30 | Keep ChromaticTrees as source of truth | Prevents duplicated or conflicting repo rules | Human Owner |
| 2026-05-30 | Default handoffs to `send: false` | Prevents silent autonomous drift | Human Owner |
| 2026-05-30 | Treat hooks as experimental/report-only initially | Avoids deterministic automation causing damage | Human Owner |
