# Risk Register

| ID | Risk | Severity | Likelihood | Mitigation | Status |
|---|---|---:|---:|---|---|
| R-001 | Agent modifies files outside scope | High | Medium | Allowed/forbidden files in mission packet | Open |
| R-002 | MCP server exposes excessive access | High | Medium | Gated MCP policy, local-only first | Open |
| R-003 | Hooks block or mutate unexpectedly | High | Medium | Report-only first | Open |
| R-004 | Copilot context becomes bloated | Medium | High | Short global instructions, scoped instructions | Open |
| R-005 | Agents duplicate governance rules | Medium | Medium | Source-of-truth hierarchy | Open |
| R-006 | GO-mode becomes too broad | High | High | Confidence gate and one-task queue selection | Open |
