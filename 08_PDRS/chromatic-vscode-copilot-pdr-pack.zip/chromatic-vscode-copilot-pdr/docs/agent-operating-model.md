# Agent Operating Model

## Role Split

Agents are intentionally narrow. The goal is not to make one genius mega-agent. The goal is to prevent drift by separating planning, building, review, QA, docs, security, and incident containment.

## Standard Flow

```text
Observe -> Classify -> Score -> Decide -> Execute -> Validate -> Record -> Queue Next
```

## Confidence Bands

| Score | Band | Allowed Action |
|---:|---|---|
| 90-100 | Very High | Scoped execution |
| 75-89 | High | Scoped execution with logging |
| 60-74 | Medium | Reversible low-risk changes only |
| 40-59 | Low | Plan only |
| 0-39 | Blocked | Halt and escalate |

## Stop Conditions

Stop if:

- Required context is missing.
- Allowed files are unclear.
- The task crosses a human gate.
- Validation fails and the cause is unclear.
- The agent repeats searches without new evidence.
- The agent wants to modify unrelated files.
