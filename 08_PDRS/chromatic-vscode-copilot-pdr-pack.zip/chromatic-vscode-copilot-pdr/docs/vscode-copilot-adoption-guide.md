# VS Code Copilot Adoption Guide

## Install

1. Copy this package into the repo root.
2. Open the repo in VS Code.
3. Install recommended extensions.
4. Run `Chromatic: Validate VS Code AI Pack` from VS Code tasks.
5. Open `Chat: Open Customizations` and confirm agents/prompts/instructions are visible.

## First Use

Use the `GO Mode` prompt or select `Chromatic Orchestrator`.

The Orchestrator should:

1. Read sprint state.
2. Read handoff queue.
3. Score confidence.
4. Select one task.
5. Produce a mission packet.
6. Hand off without auto-submit.

## Rules

- Keep global instructions short.
- Put scoped rules in `.github/instructions`.
- Put reusable workflows in `.github/prompts`.
- Put persistent roles in `.github/agents`.
- Put reusable capabilities in `.github/skills`.
- Treat MCP as privileged access.
- Treat hooks as experimental until proven safe.
