# Source Notes

This pack was designed around the VS Code Copilot customization model:

- Custom agents for persistent personas, tool restrictions, model preferences, and handoffs.
- Prompt files for one-off reusable workflows.
- Agent skills for portable reusable capabilities with scripts/resources.
- MCP servers for controlled external tools.
- Hooks for deterministic automation and policy enforcement.

The pack also follows Chromatic Harness governance:

- `CHROMATIC_TREES.md` is the repo-tree source of truth.
- Worktree maps provide machine-readable structure.
- Memory/logging files preserve repo learning.
- Agent and editor files defer to governance rather than duplicating it.
