# Hook Policy

Hooks are useful because they are deterministic. They are dangerous because deterministic automation can still cause deterministic damage.

## Adoption Stages

| Stage | Mode | Allowed Behavior |
|---:|---|---|
| 1 | Report | Log suspicious action only |
| 2 | Warn | Warn before risky action |
| 3 | Block | Block known dangerous commands |
| 4 | Auto-fix | Format or fix safe files only |

## Safe Early Hooks

- Log agent runs.
- Detect secret-like strings.
- Warn on root file creation.
- Warn on edits to CI/deployment files.
- Run formatter in report-only mode.

## Dangerous Hooks

Do not enable early:

- Auto-delete files.
- Auto-move files.
- Auto-commit.
- Auto-push.
- Auto-deploy.
- Auto-edit infrastructure.
