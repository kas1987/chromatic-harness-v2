from pathlib import Path
import sys

ROOT = Path.cwd()
REQUIRED = [
    "CHROMATIC_TREES.md",
    "WORKTREE_MAP.json",
    "AGENT_HANDOFF_QUEUE.md",
    "SPRINT_STATE.md",
    "DECISION_LOG.md",
    "RISK_REGISTER.md",
    "RUN_LOG.jsonl",
    ".github/copilot-instructions.md",
    ".github/instructions/repo-governance.instructions.md",
    ".github/prompts/go-mode.prompt.md",
    ".github/agents/chromatic-orchestrator.agent.md",
    ".github/agents/feature-builder.agent.md",
    ".vscode/settings.json",
    ".vscode/tasks.json",
    ".vscode/mcp.json",
]

missing = [p for p in REQUIRED if not (ROOT / p).exists()]

agent_dir = ROOT / ".github" / "agents"
agent_count = len(list(agent_dir.glob("*.agent.md"))) if agent_dir.exists() else 0

skill_dir = ROOT / ".github" / "skills"
skill_count = len([p for p in skill_dir.glob("*/SKILL.md")]) if skill_dir.exists() else 0

errors = []
if missing:
    errors.append("Missing required files:\n" + "\n".join(f"- {p}" for p in missing))
if agent_count < 8:
    errors.append(f"Expected at least 8 agents, found {agent_count}")
if skill_count < 3:
    errors.append(f"Expected at least 3 skills, found {skill_count}")

for agent in agent_dir.glob("*.agent.md") if agent_dir.exists() else []:
    txt = agent.read_text(encoding="utf-8")
    if "send: false" not in txt and "handoffs:" in txt:
        errors.append(f"Agent handoff should default to send false: {agent}")

if errors:
    print("Chromatic VS Code AI pack validation FAILED")
    print("\n\n".join(errors))
    sys.exit(1)

print("Chromatic VS Code AI pack validation PASSED")
print(f"Agents: {agent_count}")
print(f"Skills: {skill_count}")
