# Agent Mission Packet

## Task ID

## Assigned Model
Sonnet / Kimi

## Role
Architect / Builder / Reviewer / Scout

## Objective
[One clear outcome]

## Allowed Files
[List exact paths]

## Forbidden Files
[List protected paths]

## Context
[Relevant project state only]

## Instructions
1. Do the smallest safe next step.
2. Score confidence before action.
3. Stay inside allowed files.
4. Log assumptions.
5. Stop if scope expands.

## Tool Budget
Max tool calls: [number]

## Risk Level
Low / Medium / High / Critical

## Acceptance Criteria
- [criterion]
- [criterion]
- [criterion]

## Stop Conditions
Stop if:
- required context is missing
- destructive action is needed
- tests fail twice
- scope expands
- confidence falls below 60

## Output Required
- Summary
- Files touched
- Confidence score
- Evidence
- Next recommended task
