# Model Routing Rules: Sonnet + Kimi

## Default Routing

| Task Type | Preferred Model | Reason |
|---|---|---|
| Architecture | Sonnet | Strong synthesis and design reasoning |
| PDR writing | Sonnet | Strong structure and documentation |
| Governance review | Sonnet | Better risk and contradiction review |
| Repo scanning | Kimi | Strong long-context file digestion |
| Implementation draft | Kimi | Useful builder/refactor model |
| Refactor pass | Kimi | Good scoped worker |
| Final audit | Sonnet | Strong review and critique |

## Required Pattern

```text
Kimi builds -> Sonnet reviews -> Human/Orchestrator approves or reroutes
```

## High-Risk Pattern

```text
Sonnet plans -> Kimi implements -> Sonnet audits -> Human approves
```

## Anti-Patterns

- Do not let Kimi self-approve high-impact changes.
- Do not let Sonnet endlessly re-plan without producing a queue item.
- Do not dispatch either model without a mission packet.
- Do not allow either model to wander outside allowed files.
