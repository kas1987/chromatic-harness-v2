# Confidence Gate

## Purpose

Prevent Sonnet or Kimi from mutating project state before scope, evidence, risk, and reversibility are clear.

## Required Score Block

```json
{
  "confidence_score": 0,
  "risk_level": "low | medium | high | critical",
  "scope_clarity": 0,
  "evidence_quality": 0,
  "reversibility": "yes | partial | no",
  "decision": "execute | plan_only | halt"
}
```

## Thresholds

| Confidence | Band | Allowed Action |
|---:|---|---|
| 90-100 | Very High | Execute scoped task |
| 75-89 | High | Execute with logging |
| 60-74 | Medium | Only reversible low-risk changes |
| 40-59 | Low | Plan only |
| 0-39 | Blocked | Halt |

## Stop Rule

If confidence drops below the band required for the current action, stop and report the reason.
