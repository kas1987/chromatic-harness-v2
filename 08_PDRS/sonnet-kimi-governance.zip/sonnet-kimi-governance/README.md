# Sonnet + Kimi Governance Pack

This zip contains a lightweight PDR and governance controls for running Sonnet and Kimi as a governed two-model workflow.

## Contents

- `docs/pdr/PDR-GOV-SONNET-KIMI-001.md`
- `docs/governance/AGENT_MISSION_PACKET_TEMPLATE.md`
- `docs/governance/CONFIDENCE_GATE.md`
- `docs/governance/MODEL_ROUTING_RULES.md`
- `docs/governance/AGENT_RUN_LOG.jsonl`

## Recommended Use

1. Add these files to your repo.
2. Use the mission packet for every Sonnet or Kimi task.
3. Require confidence scoring before mutation.
4. Route Kimi as builder/scout and Sonnet as architect/reviewer.
5. Append every run to `AGENT_RUN_LOG.jsonl`.
