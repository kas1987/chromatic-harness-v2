# Agent Handoff: Create Transcript Summary Index

## Role

You are acting as a data/indexing implementer.

## Objective

Design a low-token transcript summary index so agents do not need to scan raw `~/.claude/projects/**/*.jsonl` files during normal workflows.

## Requirements

1. Do not ingest all transcript content into the active LLM context.
2. Create metadata summaries outside the prompt context.
3. Store per-project summaries with counts, dates, topics, and notable files.
4. Allow agents to query summaries first.
5. Require explicit approval to open raw transcript files.

## Suggested Output Files

- `.claude/indexes/transcript_summary_index.json`
- `.claude/indexes/transcript_summary_README.md`
- `.claude/scripts/build_transcript_summary_index.py`

## Acceptance Criteria

- Raw transcripts are not pasted into agent context.
- Summary index is compact and queryable.
- Index includes project path, date range, file count, approximate size, and topic labels.
- Deep transcript access remains gated.

## Stop Conditions

Stop if asked to read full raw transcripts into context or produce large pasted excerpts.
