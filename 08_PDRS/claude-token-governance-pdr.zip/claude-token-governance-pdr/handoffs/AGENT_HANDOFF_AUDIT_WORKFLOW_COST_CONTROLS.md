# Agent Handoff: Audit Workflow Cost Controls

## Role

You are acting as an auditor.

## Objective

Verify that the workflow governance implementation prevents token runaway and context amplification.

## Audit Checklist

- [ ] `00_WORKFLOW_GOVERNANCE.md` exists.
- [ ] `WORKFLOW_BUDGET_CONTRACT.md` exists.
- [ ] `HANDOFF_PACKET_SCHEMA.md` exists.
- [ ] Every workflow defines a budget class.
- [ ] Every `agent()` call has a cost gate.
- [ ] No workflow passes full prior outputs forward.
- [ ] Transcript glob access is blocked or gated.
- [ ] Deep audit requires explicit approval.
- [ ] Output caps are visible.
- [ ] Stop conditions are defined.

## Output Required

Produce a scorecard:

| Domain | Pass/Fail | Evidence | Risk | Fix |
|---|---|---|---|---|

## Stop Conditions

Stop if the audit requires reading broad transcript history. This audit is only allowed to inspect workflow code and governance docs.
