# Agent Handoff: Implement Claude Workflow Governance

## Role

You are acting as a code implementer.

## Objective

Add workflow-level cost controls to the Claude workflow layer and patch unsafe context chaining.

## Context

A previous Claude Code session burned approximately 1.3M tokens during a broad audit and workflow deployment. The main risks are transcript mining, skill over-reading, large tool outputs, and full-output workflow chaining.

## Inputs

- `PDR_CLAUDE_WORKFLOW_TOKEN_GOVERNANCE.md`
- `docs/00_WORKFLOW_GOVERNANCE.md`
- `docs/WORKFLOW_BUDGET_CONTRACT.md`
- `docs/HANDOFF_PACKET_SCHEMA.md`
- `workflow_patches/ship_js_patch_spec.md`

## Instructions

1. Add governance docs to `.claude/workflows/`.
2. Patch `ship.js` using the patch spec.
3. Add budget constants to each workflow file.
4. Add cost gates before every `agent()` call.
5. Replace full-output chaining with compressed handoff packets.
6. Do not access transcript files.
7. Do not broaden scope beyond workflow governance.

## Output Required

- Summary of files changed
- Diff summary
- Any skipped changes with reason
- Validation checklist result

## Acceptance Criteria

- Every workflow has a budget header.
- Every `agent()` call has a budget gate.
- No phase passes raw full output into a later phase.
- Transcript access is forbidden by default.

## Stop Conditions

Stop and report if:

- workflow paths are missing;
- existing workflow API shape is unclear;
- patching requires destructive changes;
- tests cannot be run;
- scope expands into unrelated repo cleanup.
