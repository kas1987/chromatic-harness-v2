# Claude Token Governance PDR Package

This package contains a PDR and implementation handoff suite for preventing Claude workflow token runaway.

## Contents

- `PDR_CLAUDE_WORKFLOW_TOKEN_GOVERNANCE.md` — main project design record
- `docs/00_WORKFLOW_GOVERNANCE.md` — governing rules for `.claude/workflows/`
- `docs/WORKFLOW_BUDGET_CONTRACT.md` — token/tool/file budget contract
- `docs/HANDOFF_PACKET_SCHEMA.md` — compressed handoff packet schema
- `docs/COST_INCIDENT_TEMPLATE.md` — incident review template
- `workflow_patches/ship_js_patch_spec.md` — patch spec for unsafe `ship.js` chaining
- `handoffs/*.md` — agent-ready task handoffs
- `templates/WORKFLOW_BUDGET_HEADER_TEMPLATE.js` — reusable JS budget guard template
- `tests/ACCEPTANCE_CHECKLIST.md` — completion checklist

## Recommended First Move

Copy these files into a versioned governance folder, then install the workflow docs into:

```text
C:\Users\kas41\.claude\workflows\
```

Patch `ship.js` before running any chained workflow again.
